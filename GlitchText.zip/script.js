const normalText = document.getElementById("normalText");
const glitchSlider = document.getElementById("glitchSlider");
const glitchText = document.getElementById("glitchText");

glitchSlider.addEventListener("input", updateGlitch);

function updateGlitch() {
  const glitchLevel = glitchSlider.value / 100;
  const glitchedText = glitchify(normalText.value, glitchLevel);
  glitchText.textContent = glitchedText;
}

function glitchify(text, level) {
  // Implement glitch logic here
  // Example: Randomly replace characters based on level
  let newText = "";
  for (let i = 0; i < text.length; i++) {
    if (Math.random() < level) {
      newText += String.fromCharCode(Math.random() * 128);
    } else {
      newText += text[i];
    }
  }
  return newText;
}